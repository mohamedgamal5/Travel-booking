<?php

    include 'Connect.php';

    $number = $_GET['number'];
    $flight = $_GET['flight'];
    $passenger = $_GET['passenger'];

    $sqlQuery = "INSERT INTO aircraft VALUES ('$number', '$flight', '$passenger');";
    
    if ($conn->query($sqlQuery) === TRUE) {
        header("Location: ../php/Admin/Admin.php?addaircraft=success");
    }

    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: ../php/Admin/Admin.php?addaircraft=fail");
    }

    $conn->close();