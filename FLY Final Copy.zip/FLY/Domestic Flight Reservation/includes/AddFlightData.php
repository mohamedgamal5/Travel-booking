<?php

    include 'Connect.php';

    $number = $_GET['number'];
    $fdate = $_GET['fdate'];
    $departure = $_GET['departure'];
    $arrival = $_GET['arrival'];
    $passenger = $_GET['passenger'];

    $sqlQuery = "INSERT INTO flight VALUES ('$number', '$fdate', '$departure', '$arrival', '$passenger');";
    
    if ($conn->query($sqlQuery) === TRUE) {
        header("Location: ../php/Admin/Admin.php?addflight=success");
    }

    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: ../php/Admin/Admin.php?addflight=fail");
    }

    $conn->close();