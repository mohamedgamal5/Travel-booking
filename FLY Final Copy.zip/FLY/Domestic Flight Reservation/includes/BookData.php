<?php

    include 'Connect.php';

    session_start();
    $email = $_SESSION['email'];

    $flight = $_GET['book'];

    $sqlQuery = "UPDATE flyuser SET flight='$flight' WHERE email='$email';";
    
    if ($conn->query($sqlQuery) === TRUE) {
        header("Location: ../php/Flight/Flight.php?book=success");
    }

    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: ../php/Flight/Flight.php?book=fail");
    }

    $conn->close();