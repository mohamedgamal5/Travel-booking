
/** This Page to cancel the booking of a flight*/

<?php

    include 'Connect.php';

    session_start();

    $username = $_SESSION['username'];
    $cancelQuery = "UPDATE flyuser SET flight=0 WHERE username='$username';";

    $conn->query($cancelQuery);
    header("Location: ../php/Profile/Profile.php");