
/** This Page connects the Databse */

<?php 

    $servername = "localhost";
    $username = "root";
    $password = "";
    $database = "fly";

    $conn = new mysqli($servername, $username, $password, $database);