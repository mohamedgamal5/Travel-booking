<?php

    include 'Connect.php';

    $number = $_GET['number'];
    $flight = $_GET['flight'];

    $sqlQuery = "DELETE FROM aircraft WHERE number='$number' AND flight='$flight';";
    
    if ($conn->query($sqlQuery) === TRUE) {
        header("Location: ../php/Admin/Admin.php?deleteflight=success");
    }

    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: ../php/Admin/Admin.php?deleteflight=fail");
    }

    $conn->close();