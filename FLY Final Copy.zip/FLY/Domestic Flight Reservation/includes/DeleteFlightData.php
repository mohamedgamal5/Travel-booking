<?php

    include 'Connect.php';

    $number = $_GET['number'];
    $fdate = $_GET['fdate'];

    $sqlQuery = "DELETE FROM flight WHERE number='$number' AND fdate='$fdate';";
    
    if ($conn->query($sqlQuery) === TRUE) {
        header("Location: ../php/Admin/Admin.php?deleteflight=success");
    }

    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: ../php/Admin/Admin.php?deleteflight=fail");
    }

    $conn->close();