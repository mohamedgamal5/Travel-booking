<?php

    include 'Connect.php';

    $fname = $_GET['fname'];
    $lname = $_GET['lname'];
    $mobile = $_GET['mobile'];

    session_start();
    $username = $_SESSION['username'];

    $sqlQuery = "UPDATE flyuser SET fname='$fname', lname='$lname', mobile='$mobile' WHERE username='$username';";
    
    if ($conn->query($sqlQuery) === TRUE) {
        header("Location: ../php/Profile/Profile.php?editprofile=success");
    }

    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: ../php/Profile/Profile.php?editprofile=fail");
    }

    $conn->close();