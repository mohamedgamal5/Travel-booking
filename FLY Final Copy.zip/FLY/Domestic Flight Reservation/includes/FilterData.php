<?php

    include 'Connect.php';

    if (isset($_GET['Date'])){
        session_start();
        $_SESSION['filterQuery'] = "SELECT * FROM flight ORDER BY fdate;";
        header("Location: ../php/Flight/Flight.php");
    }

    else if (isset($_GET['Source'])){
        session_start();
        $_SESSION['filterQuery'] = "SELECT * FROM flight ORDER BY departure;";
        header("Location: ../php/Flight/Flight.php");
    }

    else if (isset($_GET['Destination'])){
        session_start();
        $_SESSION['filterQuery'] = "SELECT * FROM flight ORDER BY arrival;";
        header("Location: ../php/Flight/Flight.php");
    }

    else if (isset($_GET['Passenger'])){
        session_start();
        $_SESSION['filterQuery'] = "SELECT * FROM flight ORDER BY passenger;";
        header("Location: ../php/Flight/Flight.php");
    }

    else if (isset($_GET['search'])){
        $arrival = $_GET['arrival'];
        session_start();
        $_SESSION['filterQuery'] = "SELECT * FROM flight WHERE arrival='$arrival';";
        header("Location: ../php/Flight/Flight.php");
    }

    else if (isset($_GET['searchBar'])){

        $departure = $_GET['departure'];
        $arrival = $_GET['arrival'];
        $fdate = $_GET['fdate'];
        $passenger = $_GET['passenger'];

        session_start();
        $_SESSION['filterQuery'] = "SELECT * FROM flight WHERE departure='$departure' AND arrival='$arrival' AND fdate='$fdate' AND passenger='$passenger';";
        header("Location: ../php/Flight/Flight.php");
    }