
/** This Page log out the user in */

<?php

    include 'Connect.php';

    session_start();
    session_unset();
    session_destroy();

    header("Location: ../php/Home/VisitorHome.php");