
/** This Page login the user in */

<?php

    include 'Connect.php';

    $email = $_POST['email'];
    $password = $_POST['password'];

    $sqlQuery = "SELECT * FROM flyuser WHERE flyuser.email = '$email';";
    $result = $conn->query($sqlQuery);
    
    if ($row = $result->fetch_assoc()){
 
        if ($row['prd'] == $password){

            session_start();
            $_SESSION['email'] = $email;
            $_SESSION['role'] = $row['role'];
            header("Location: ../php/Profile/Profile.php?signin.php=succes");
        }

        else {
            header("Location: ../php/Register/Sign.php?signin.php=fail");
        }
    }