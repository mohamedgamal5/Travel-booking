
/** This Page stores the data from the Sign-up page in the Database */

<?php

    include 'Connect.php';

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $mobile = $_POST['mobile'];
    $role = "Traveller";

    $sqlQuery = "INSERT INTO flyuser VALUES ('$fname', '$lname', '$username', '$email', '$password', '$mobile', '$role')";

    if ($conn->query($sqlQuery) === TRUE){

        session_start();
        $_SESSION['email'] = $email;
        $_SESSION['role'] = $row['role'];
        header("Location: ../php/Profile/Profile.php?signup=success");
    }

    else {
        header("Location: ../php/Register/Sign.php?signup=fail");
    }