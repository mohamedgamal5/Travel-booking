<?php

    include 'Connect.php';

    $number = $_GET['number'];
    $flight = $_GET['flight'];
    $passenger = $_GET['passenger'];

    $sqlQuery = "UPDATE aircraft SET flight='$flight', passenger='$passenger' WHERE number='$number';";
    
    if ($conn->query($sqlQuery) === TRUE) {
        header("Location: ../php/Admin/Admin.php?updateaircraft=success");
    }

    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: ../php/Admin/Admin.php?updateaircraft=fail");
    }

    $conn->close();