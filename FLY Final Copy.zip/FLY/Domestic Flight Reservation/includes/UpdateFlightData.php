<?php

    include 'Connect.php';

    $number = $_GET['number'];
    $fdate = $_GET['fdate'];
    $departure = $_GET['departure'];
    $arrival = $_GET['arrival'];
    $passenger = $_GET['passenger'];

    $sqlQuery = "UPDATE flight SET fdate='$fdate', departure='$departure', arrival='$arrival', passenger='$passenger' WHERE number='$number';";
    
    if ($conn->query($sqlQuery) === TRUE) {
        header("Location: ../php/Admin/Admin.php?updateflight=success");
    }

    else {
        echo "Error: " . $sql . "<br>" . $conn->error;
        header("Location: ../php/Admin/Admin.php?updateflight=fail");
    }

    $conn->close();