const name = document.getElementById('name').value
const password = document.getElementById('password')
const form = document.getElementById('form')
const errorMess = document.getElementById('error')

form.addEventListener('submit', (e) => {

    let messages = []
    if (name.value === '' || name.value == null){
        messages.push('User name is required')
    }

    if (messages.length > 0){
        e.preventDefault()
        errorMess.innerText = messages.join(', ')
    }
})