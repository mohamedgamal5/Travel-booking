
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Admin/Option.css">

    </head>

    <body>
        
        <div class="flightAdd">

            <form action="../../includes/AddFlightData.php" method="GET">

                <h1 class="ins"> Write Flight Number </h1>
                <input class="number" name="number" type="number" placeholder="EX: #1150" required>

                <h1 class="ins"> Write Flight Date </h1>
                <input class="date" name="fdate" type="date" placeholder="EX: 26/05/2020" required>

                <h1 class="ins"> Write Departure Place </h1>
                <input class="departure" name="departure" type="text" placeholder="EX: Cairo" required>

                <h1 class="ins"> Write Arrival Place </h1>
                <input class="arrival" name="arrival" type="text" placeholder="EX: Paris" required>

                <h1 class="ins"> Write Number of Passengers </h1>
                <input class="passenger" name="passenger" type="number" placeholder="EX: 300" required>

                <input type="submit" class="submit">

            </form>

        </div>

    </body>

</html>