<!DOCTYPE html>
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Admin/Admin.css">
        <title> Admin </title>

    </head>

    <body>

         <!-- The NavBar -->
         <div class="navBar">
            <div class="container">

                <a class="logo" href="#"> FLY </a>

                <a class="signButton" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Home/VisitorHome.php"> <button> Log out </button> </a>

                <a class="home navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Home/UserHome.php"> Home </a>
                
                <a class="flights navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Flight/Flight.php"> Flights </a>
                
                <a class="profile navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Profile/Profile.php"> Profile </a>
                
                <a class="admin navLink" href="#"> Admin </a>

            </div>   
        </div>
        

        <!-- Options Menu -->
        <div class="admin">

            <div class="optionMenu">

                <button onclick="addFlight();"> Add a Flight </button>
                <br>
                <button onclick="updateFlight();"> Update a Flight </button>
                <br>
                <button onclick="deleteFlight();"> Delete a Flight </button>
                <br>
                <button onclick="addAircraft();"> Add an Aircraft </button>
                <br>
                <button onclick="updateAircraft();"> Update an Aircraft </button>
                <br>
                <button onclick="deleteAircraft();"> Delete an Aircraft </button>
    
            </div>
    
            <div class="option" id="option">
    
            </div>

        </div>


        <div>

            <script>

                //This Function is called to import the add flight page
                function addFlight() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("option").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "AddFlight.php", true);
                    request.send();
                }





                //This Function is called to import the update flight page
                function updateFlight() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("option").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "UpdateFlight.php", true);
                    request.send();
                }






                //This Function is called to import the delete flight page
                function deleteFlight() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("option").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "DeleteFlight.php", true);
                    request.send();
                }






                //This function is called to import the add aircraft page
                function addAircraft() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("option").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "AddAircraft.php", true);
                    request.send();
                }






                //This function is called to import the update aircraft page
                function updateAircraft() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("option").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "UpdateAircraft.php", true);
                    request.send();
                }







                //This function is called to import the delete aircraft page
                function deleteAircraft() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("option").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "DeleteAircraft.php", true);
                    request.send();
                }

            </script>

        </div>

    </body>

</html>