
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Admin/Option.css">

    </head>

    <body>
        
        <div class="flightAdd">

            <form action="../../includes/DeleteAircraftData.php" metho="GET">

                <br><br><br><br><br>
                <h1 class="ins"> Write the Deleted Aircraft Number </h1>
                <input class="number" type="number" name="number" placeholder="EX: #1150" required>

                <br><br><br><br><br>
                <h1 class="ins"> Write the Deleted Aircraft Flight Number </h1>
                <input class="flightNumber" type="number" name="flight" placeholder="EX: #1150" required>

                <input type="submit" class="submit">

            </form>

        </div>

    </body>

</html>