
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Admin/Option.css">

    </head>

    <body>
        
        <div class="flightAdd">

            <form action="../../includes/UpdateAircraftData.php" metho="GET">

                <br><br><br>
                <h1 class="ins"> Write Aircraft Number </h1>
                <input class="number" type="number" name="number" placeholder="EX: #1150" required>

                <br><br><br>
                <h1 class="ins"> Write the New Aircraft Flight Number </h1>
                <input class="flightNumber" type="number" name="flight" placeholder="EX: #1150" required>

                <br><br><br>
                <h1 class="ins"> Write the New Aircraft Capacity </h1>
                <input class="passenger" type="number" name="passenger" placeholder="EX: 300" required>

                <input type="submit" class="submit">

            </form>

        </div>

    </body>

</html>