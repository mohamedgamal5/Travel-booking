
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Admin/Option.css">

    </head>

    <body>
        
        <div class="flightAdd">

            <form action="../../includes/UpdateFlightData.php" method="GET">

                <h1 class="ins"> Write Flight Number </h1>
                <input class="number" type="number" name="number" placeholder="EX: #1150" required>

                <h1 class="ins"> Write the New Flight Date </h1>
                <input class="date" type="date" name="fdate" placeholder="EX: 26/05/2020" required>

                <h1 class="ins"> Write the New Departure Place </h1>
                <input class="departure" type="text" name="departure" placeholder="EX: Cairo" required>

                <h1 class="ins"> Write the New Arrival Place </h1>
                <input class="arrival" type="text" name="arrival" placeholder="EX: Paris" required>

                <h1 class="ins"> Write the New Number of Passengers </h1>
                <input class="passenger" type="number" name="passenger" placeholder="EX: 300" required>

                <input type="submit" class="submit">

            </form>

        </div>

    </body>

</html>