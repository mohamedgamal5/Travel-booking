<!DOCTYPE html>
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Flight/Book.css">

    </head>

    <body>
        
        <div class="book">
            <button> <p>Travel</p><p>Is</p><p>Yours</p> </button>
        </div>

    </body>

</html>