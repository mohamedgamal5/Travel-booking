<!DOCTYPE html>
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Flight/Flight.css">

    </head>

    <body>



        <!-- Connect to the Database -->
        <?php

            $servername = "localhost";
            $username = "root";
            $password = "";
            $db = "fly";

            $conn = new mysqli($servername, $username, $password, $db);

        ?>

        
        <!-- The NavBar -->
        <div class="navBar">
            <div class="container">

                <a class="logo" href="#"> FLY </a>

                <a class="signButton" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Home/VisitorHome.php"> <button> Log out </button> </a>

                <a class="home navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Home/UserHome.php"> Home </a>
                
                <a class="flights navLink" href="#"> Flights </a>
                
                <a class="profile navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Profile/Profile.php"> Profile </a>
                
                <?php session_start(); ?>
                <?php if ($_SESSION['role'] == 'Admin') { ?>
                    <a class="admin navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Admin/Admin.php"> Admin </a>
                <?php } ?>

                <?php if ($_SESSION['role'] == 'Traveller') { ?>
                    <a class="admin navLink" href="#"> About </a>
                <?php } ?>

            </div>   
        </div>




        <div class="full">

            <!-- Filter -->
            <div class="filter">

                <h1> Filter </h1>

                <form action="../../includes/FilterData.php" method="GET">

                    <input type="submit" name="Date" value="Date">
                    <br>
                    <input type="submit" name="Source" value="Source">
                    <br>
                    <input type="submit" name="Destination" value="Destination">
                    <br>
                    <input type="submit" name="Passenger" value="Passenger Limit">

                    <!-- Search Field -->
                    <form action="../../includes/FilterData.php" method="GET">
                        <input class="search" type="text" name="arrival" placeholder="Search with Destination ex: Paris">
                        <input class="searchButton" type="submit" name="search" value="search">
                    </form>
                
                </form>

            </div>



            <?php

                if ($_SESSION['filterQuery'] !== NULL){
                    $sqlQuery = $_SESSION['filterQuery'];
                }

                else {
                    $sqlQuery = "SELECT * FROM flight";
                }

                $result = $conn->query($sqlQuery);

            ?>



            <!-- Flight Menu -->
            <div class="flightMenu">

                <?php if ($result->num_rows > 0){ ?>

                    <?php while ($row = $result->fetch_assoc()){ ?>

                        <!-- Flight Card -->
                        <div class="flightCard">

                            <img src="<?php echo $row['image'] ?>" alt="">

                            <div class="info">

                                <h1> <?php echo $row['arrival'] ?> </h1>

                                <h2> Date: <?php echo $row['fdate'] ?> </h2>
                                <h2> Source: <?php echo $row['departure'] ?> </h2>
                                <h2> Destination: <?php echo $row['arrival'] ?> </h2>
                                <h2> Passengers: <?php echo $row['passenger'] ?> </h2>

                            </div>

                            <div class="book" id="book">

                                <p>Click To Book</p>

                                <form action="../../includes/BookData.php" metho="GET">
                                    <input type="submit" name="book" value="<?php echo $row['number']?>">
                                </form>

                            </div>

                        </div>

                    <?php } ?>
                
                <?php } ?>

            </div>

        </div>




        <!-- The Footer -->

        <div class="footer">

            <div class="container">

                <div class="footerInfo">

                    <h1> Explore </h1>

                    <a href="#"> <h2> Cities </h2> </a>
                    <a href="#"> <h2> City Breaks </h2> </a>
                    <a href="#"> <h2> Airports </h2> </a>
                    <a href="#"> <h2> Countries/Regions </h2> </a>
                    <a href="#"> <h2> Flights </h2> </a>

                </div>

                <div class="footerInfo">

                    <h1> About FLY </h1>

                    <a href="#"> <h2> About us </h2> </a>
                    <a href="#"> <h2> Why FLY? </h2> </a>
                    <a href="#"> <h2> Cookie Policy </h2> </a>
                    <a href="#"> <h2> Privacy Policy </h2> </a>
                    <a href="#"> <h2> Terms of Services </h2> </a>

                </div>

                <div class="footerInfo">

                    <h1> Book </h1>

                    <a href="#"> <h2> Book A Flight </h2> </a>
                    <a href="#"> <h2> My Bookings </h2> </a>
                    <a href="#"> <h2> Airports </h2> </a>
                    <a href="#"> <h2> Charter Flights </h2> </a>
                    <a href="#"> <h2> Group Reservation </h2> </a>

                </div>

                <div class="footerInfo">

                    <h1> Help </h1>

                    <a href="#"> <h2> Help </h2> </a>
                    <a href="#"> <h2> Privacy Settings </h2> </a>
                    <a href="#"> <h2> Security </h2> </a>
                    <a href="#"> <h2> Countries/Regions </h2> </a>
                    <a href="#"> <h2> Flights </h2> </a>

                </div>

                <br>

                <h3 class="rights"> © 2020-2022 FLY, All Rights Reserved </h3>

            </div>

        </div>




        <!-- The Ajax Button -->
        <div>

            <script>

                //This Function is called to import the book button page
                function book() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("book").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "Book.php", true);
                    request.send();
                }

            </script>

        </div>

    </body>

</html>