<!DOCTYPE html>
<html lang="en">

    <head>
    
        <title> Fly </title>
        <link rel="stylesheet" href="../../css/Home/UserHome.css">

    </head>

    <body>

        <!-- The NavBar -->
        <div class="navBar">
            <div class="container">

                <a class="logo" href="#"> FLY </a>

                <a class="signButton" href="../../includes/LogoutData.php"> <button> Log out </button> </a>

                <a class="home navLink" href="#"> Home </a>
                
                <a class="flights navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Flight/Flight.php"> Flights </a>
                
                <a class="profile navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Profile/Profile.php"> Profile </a>

                <?php session_start(); ?>
                <?php if ($_SESSION['role'] == 'Admin') { ?>
                    <a class="admin navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Admin/Admin.php"> Admin </a>
                <?php } ?>

                <?php if ($_SESSION['role'] == 'Traveller') { ?>
                    <a class="admin navLink" href="#"> About </a>
                <?php } ?>

            </div>   
        </div>


        <!-- The Carousel -->
        <div class="carousel">
            
            <h1 class="slogan"> FLY to Travel </h1>

            <h1> Where To ?</h1>

            <!-- Reservation Bar -->
            <div class="reserve"> 

                <form action="../../includes/FilterData.php" method="GET">
                
                    <input class="departure" type="text" name="departure" placeholder="Departure">

                    <input class="arrival" type="text" name="arrival" placeholder="Arrival">

                    <input class="date" type="date" name="fdate">

                    <input class="passengre" type="number" name="passenger" placeholder="Passenger">

                    <input class="search" type="submit" name="searchBar" value="Search">

                </form>
            </div>

            <h3> Book in FLY and Fasten your Seatbelt </h3>

        </div>

        
        <!-- The Obiectives -->
        <div class="container objs">
            <div class="objective1 obj">

                <h2> Find Destination </h2>

                <p> 
                FLY website serves the customer comfort. The website helps
                the customer to find the flights, he wants, from the source, the customer 
                defines, to the destination, the customer decides. The customer could 
                find the flights, that suits his desires, with the best price.
                </p>

            </div>

            <div class="objective2 obj">

                <h2> Let's Travel </h2>

                <p> 
                There are many things make difference for the customer in FLY, you will 
                discover all those qualifications by the time you are a member in FLY 
                community. But the important qualification that distinguish FLY from other 
                travel systems is that you could reach your destination in the fastest way.
                </p>

            </div>
        </div>

        <br>

        <!-- Recommendations -->
        <div class="container recommend">
            
            <h2> Recommendations for You </h2>

            <div class="card">

                <img src="../../img/card1.jpg" alt="">

                <h3> Paris, <span>France</span> </h3>

                <a href="#"> More Info. </a>

                <p> 
                Price: 
                Airport:
                Source:
                Destination:
                </p>

            </div>

            <div class="card">

                <img src="../../img/card2.jpg" alt="">

                <h3> Rome, <span>Italy</span> </h3>

                <a href="#"> More Info. </a>

                <p> 
                    Price: 
                    Airport:
                    Source:
                    Destination:
                </p>

            </div>

            <div class="card">

                <img src="../../img/card8.jpg" alt="">

                <h3> Hurghada, <span>Egypt</span> </h3>

                <a href="#"> More Info. </a>

                <p> 
                    Price: 
                    Airport:
                    Source:
                    Destination:
                </p>

            </div>

        </div>


        <!-- Sign-up Section -->
        <div class="container sign-up">

            <h1> Enjoy FLY Services </h1>   
            
            <h3> Find Destination and Go Travel</h3>

            <a href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Flight/Flight.php"> <h2>Enjoy Travelling</h2> </a>

        </div>

        <!-- Main Destination -->
        <div class="container main-destination">

            <h2> Main FLY Goals </h2>

            <div class="card dest1">

                <h3> Saving Time </h3>

                <p> Save your time
                    Find availabale lounges
                    at selected airports
                </p>

            </div>

            <div class="card dest2">

                <h3> Best Check-in </h3>

                <p> Save your valuable time
                    at the airport 
                    and check in online
                </p>

            </div>

            <div class="card dest3">

                <h3> Follow your Flight </h3>

                <p> Check your flight
                    status online
                    in easy and fast way
                </p>

            </div>

            <div class="card dest4">

                <h3> Technology Investment </h3>

                <p> We are investing in
                    Technology to make
                    Travel more rewarding
                </p>

            </div>

        </div>

        <br>

        <!-- The Footer -->

        <div class="footer">

            <div class="container">

                <div class="footerInfo">

                    <h1> Explore </h1>

                    <a href="#"> <h2> Cities </h2> </a>
                    <a href="#"> <h2> City Breaks </h2> </a>
                    <a href="#"> <h2> Airports </h2> </a>
                    <a href="#"> <h2> Countries/Regions </h2> </a>
                    <a href="#"> <h2> Flights </h2> </a>

                </div>

                <div class="footerInfo">

                    <h1> About FLY </h1>

                    <a href="#"> <h2> About us </h2> </a>
                    <a href="#"> <h2> Why FLY? </h2> </a>
                    <a href="#"> <h2> Cookie Policy </h2> </a>
                    <a href="#"> <h2> Privacy Policy </h2> </a>
                    <a href="#"> <h2> Terms of Services </h2> </a>

                </div>

                <div class="footerInfo">

                    <h1> Book </h1>

                    <a href="#"> <h2> Book A Flight </h2> </a>
                    <a href="#"> <h2> My Bookings </h2> </a>
                    <a href="#"> <h2> Airports </h2> </a>
                    <a href="#"> <h2> Charter Flights </h2> </a>
                    <a href="#"> <h2> Group Reservation </h2> </a>

                </div>

                <div class="footerInfo">

                    <h1> Help </h1>

                    <a href="#"> <h2> Help </h2> </a>
                    <a href="#"> <h2> Privacy Settings </h2> </a>
                    <a href="#"> <h2> Security </h2> </a>
                    <a href="#"> <h2> Countries/Regions </h2> </a>
                    <a href="#"> <h2> Flights </h2> </a>

                </div>

                <br>

                <h3 class="rights"> © 2020-2022 FLY, All Rights Reserved </h3>

            </div>

        </div>


    </body>

</html>