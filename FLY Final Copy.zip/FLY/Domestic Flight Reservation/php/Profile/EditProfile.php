<!DOCTYPE html>
<html>

    <head>

        <link rel="stylesheet" href="../../css/Profile/EditProfile.css">

    </head>


    <body>

        <?php session_start(); ?>
        
        <form action="../../includes/EditProfileData.php" method="GET">
        
            <input type="text" name="fname" placeholder="Enter New First Name" value="<?php echo $_SESSION['fname']; ?>">

            <br>

            <input type="text" name="lname" placeholder="Enter New Last Name" value="<?php echo $_SESSION['lname']; ?>">

            <br>

            <input type="text" name="username" placeholder="Enter Current Username" value="<?php echo $_SESSION['username']; ?>" disabled>

            <br>

            <input type="text" name="email" placeholder="Enter Current E-mail" value="<?php echo $_SESSION['email']; ?>" disabled>

            <br>

            <input type="text" name="mobile" placeholder="Enter New Phone Number" value="<?php echo $_SESSION['mobile']; ?>">

            <br>

            <input type="submit" class="submit" value="Change">

        </form>        

    </body>


</html>