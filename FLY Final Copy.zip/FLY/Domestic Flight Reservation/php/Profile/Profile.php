<!DOCTYPE html>
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Profile/Profile.css">
        <title> Profile </title>

    </head>

    <body>

        <!-- Connecting the Database -->
        <?php

            $servername = "localhost";
            $username = "root";
            $password = "";
            $database = "fly";

            $conn = new mysqli($servername, $username, $password, $database);

        ?>


        <!-- The NavBar -->
        <div class="navBar">
            <div class="container">

                <a class="logo" href="#"> FLY </a>

                <a class="signButton" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Home/VisitorHome.php"> <button> Log out </button> </a>

                <a class="home navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Home/UserHome.php"> Home </a>
                
                <a class="flights navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Flight/Flight.php"> Flights </a>
                
                <a class="profile navLink" href="#"> Profile </a>
                
                <?php session_start(); ?>
                <?php if ($_SESSION['role'] == 'Admin') { ?>
                    <a class="admin navLink" href="http://localhost/FLY/Domestic%20Flight%20Reservation/php/Admin/Admin.php"> Admin </a>
                <?php } ?>

                <?php if ($_SESSION['role'] == 'Traveller') { ?>
                    <a class="admin navLink" href="#"> About </a>
                <?php } ?>

            </div>   
        </div>


        

        
       <div class="full">
            <!-- Profile Section -->
            <div class="profile">

                <div class="profileImage">

                    <img src="../../img/avatar.png" alt="">

                </div>


                <!-- Using a query to get the user info -->
                <?php 

                    $email = $_SESSION['email'];
                    $sqlQuery = "SELECT * FROM flyuser WHERE flyuser.email = '$email';";
                    $result = $conn->query($sqlQuery);

                ?>


                <?php if ($result->num_rows > 0){ ?>

                    <?php while ($row = $result->fetch_assoc()){ ?>
                    
                        <div class="userInfo">

                            <h1> First Name: <?php echo $row['fname'] ?> </h1>

                            <h1> Last Name:  <?php echo $row['lname'] ?> </h1>

                            <h1> Username: <?php echo $row['username'] ?> </h1>

                            <h1> Email: <?php echo $row['email'] ?> </h1>

                            <h1> Phone Number: <?php echo $row['mobile'] ?> </h1>

                            <button class="editButton" onclick="edit();"> Edit Info </button>

                        </div>

                        <?php 
                            $_SESSION['fname'] = $row['fname'];
                            $_SESSION['lname'] = $row['lname'];
                            $_SESSION['username'] = $row['username'];
                            $_SESSION['email'] = $row['email'];
                            $_SESSION['mobile'] = $row['mobile'];
                            $flightNumber = $row['flight'];
                        ?>
                        
                    <?php } ?>
                <?php } ?>

            </div>


            <div class="edit" id="edit">

                <?php if ($flightNumber > '0'){ ?>        
                
                    <?php $flightQuery = "SELECT * FROM flight WHERE flight.number = '$flightNumber';"; ?>
                    <?php $resultFlight = $conn->query($flightQuery); ?>
                    <?php $rowFlight = $resultFlight->fetch_assoc(); ?>
 
                    <h1> Your Flight Info </h1>
                    <h2> Sorce: <?php echo $rowFlight['departure'] ?> </h1>
                    <h2> Destination: <?php echo $rowFlight['arrival'] ?> </h1>
                    <h2> Date: <?php echo $rowFlight['fdate'] ?> </h1>
                    <a href="../../includes/CancelBookData.php"><button>Cancel</button></a>

                <?php } ?>

            </div>

        </div>







        <div>

            <script>

                //This Function is called to import the add edit profile page
                function edit() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("edit").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "EditProfile.php", true);
                    request.send();
                }

            </script>

        </div>
            
    </body>

</html>