<!DOCTYPE html>
<html>

    <head>

        <link rel="stylesheet" href="../../css/Register/Sign.css">
        <title> FLY Sign-up </title>

    </head>

    <body>

        <!-- Sign up Form -->
        <div class="form">

            <h1> Welcome </h1>

            <button onclick="signUP();"> First Time </button>

            <button onclick="signIN();"> Already Joined </button>

            <div class="option" id="option">

                <h1> FLY </h1>

            </div>

        </div>



        <div>

            <script>

                //This function to call the sign up page
                function signUP() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("option").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "SignUP.php", true);
                    request.send();
                }


                //This function to call the sign in page
                function signIN() {
                    
                    var request = new XMLHttpRequest();

                    request.onreadystatechange = function() {

                        if (this.readyState == 4 && this.status == 200){
                            document.getElementById("option").innerHTML = this.responseText;
                        }
                    };

                    request.open("GET", "SignIN.php", true);
                    request.send();
                }

            </script>

        </div>

    </body>

</html>