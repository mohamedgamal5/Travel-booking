<!DOCTYPE html>
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Register/SignUPIN.css">

    </head>

    <body>
        
        <form action="../../includes/SignINData.php" method="POST">

            <br><br>

            <input type="email" name="email" placeholder="Email" required>

            <br><br>

            <input type="password" name="password" placeholder="Password" required>

            <br><br>

            <input type="submit" name="submit" class="submit" value="Sign in">

        </form>

    </body>

</html>