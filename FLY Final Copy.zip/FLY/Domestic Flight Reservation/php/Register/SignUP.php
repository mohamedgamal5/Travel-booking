<!DOCTYPE html>
<html lang="en">

    <head>

        <link rel="stylesheet" href="../../css/Register/SignUPIN.css">

    </head>

    <body>
        
        <form action="../../includes/SignUPData.php" method="POST">

            <input class="fname" type="text" name="fname" placeholder="First Name" required>
            <input class="lname" type="text" name="lname" placeholder="Last Name" required>

            <br>

            <input type="text" name="username" placeholder="User Name" required>

            <br>

            <input type="email" name="email" placeholder="Email" required>

            <br>

            <input type="password" name="password" placeholder="Password" required>

            <br>

            <input type="number_format" name="mobile" placeholder="Mobile Number" required>

            <br>

            <input type="submit" name="submit" class="submit" value="Sign up">

        </form>

    </body>

</html>